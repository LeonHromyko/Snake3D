﻿namespace GamePlay
{
    public interface IGameEntity
    {
        void Spawn(IGameManager gameManager);
        void MakeDesign();
        void Execute();
        void Die();
        void ApplyGameStateChanges();
    }
}