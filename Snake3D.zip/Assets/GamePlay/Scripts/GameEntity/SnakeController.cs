﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

namespace GamePlay
{
    public class SnakeController : BaseGameEntity
    {
        private delegate GameFieldCell MoveDirectionFunc(GameFieldCell cell);
        
        private static readonly MoveDirectionFunc[] MoveDirectionFuncs =
        {
            cell => new GameFieldCell{X = cell.X + 1, Y = cell.Y, Z = cell.Z},
            cell => new GameFieldCell{X = cell.X - 1, Y = cell.Y, Z = cell.Z},
            
            cell => new GameFieldCell{X = cell.X, Y = cell.Y + 1, Z = cell.Z},
            cell => new GameFieldCell{X = cell.X, Y = cell.Y - 1, Z = cell.Z},
            
            cell => new GameFieldCell{X = cell.X, Y = cell.Y, Z = cell.Z + 1},
            cell => new GameFieldCell{X = cell.X, Y = cell.Y, Z = cell.Z - 1},
        };
        
        private GameFieldCell _startCell;
        private readonly List<Transform> _snakeParts = new List<Transform>();
        private bool _growth;
        private MoveDirectionFunc _designedMove;
        private GameFieldCell _lastCell;
        
        public override void Spawn(IGameManager gameManager)
        {
            base.Spawn(gameManager);
            var snakeLength = _gameManager.Settings.SnakeStartLength;

            while (true)
            {
                var startCell = _gameManager.GetRandomEmptyCell();
                var fit = true;
                
                for (var dX = 1; dX < snakeLength; dX++)
                {
                    if (startCell.X + dX >= _gameManager.Settings.GameFieldSize ||
                        _gameManager.GetGameFieldCellEntities(startCell.X + dX, startCell.Y, startCell.Z).Count != 0)
                    {
                        fit = false;
                        break;
                    }
                }

                if (fit)
                {
                    _startCell = startCell;
                    for (var dX = 0; dX < snakeLength; dX++)
                    {
                        var cell = new GameFieldCell
                        {
                            X = startCell.X + dX,
                            Y = startCell.Y,
                            Z = startCell.Z
                        };
                        
                        _gameManager.AssignGameEntityToGameFieldCell(this, cell);
                        
                        var snakePart = Instantiate(_gameManager.Settings.SnakePartPrefab,
                            _gameManager.GameCellToWorldCoords(cell),
                            Quaternion.identity,
                            transform);
                        _snakeParts.Add(snakePart.transform);
                        _cells.Add(cell);
                    }
                    
                    break;
                }
            }
        }

        public override void MakeDesign()
        {
            _growth = false;
            var moves = new Dictionary<MoveDirectionFunc, int>();

            foreach (var moveDirection in MoveDirectionFuncs)
            {
                var step = 0;
                moves[moveDirection] = -1;
                var cell = _startCell;
                
                while (true)
                {
                    step++;
                    cell = moveDirection(cell);
                    if (!_gameManager.IsCellInsideGameField(cell)) break;

                    if (_gameManager.GetGameFieldCellEntities(cell).Count > 0)
                    {
                        foreach (var entity in _gameManager.GetGameFieldCellEntities(cell))
                        {
                            if (entity is FoodController)
                            {
                                moves[moveDirection] = step;
                                break;
                            }
                        }
                        
                        break;
                    }

                    moves[moveDirection] = int.MaxValue;
                }
            }

            var bestPriority = int.MaxValue;
            foreach (var priority in moves.Values)
            {
                if (priority < bestPriority && priority >= 0)
                    bestPriority = priority;
            }
            
            var bestMoves = new List<MoveDirectionFunc>();
            foreach (var kvp in moves)
            {
                if (kvp.Value == bestPriority)
                    bestMoves.Add(kvp.Key);
            }

            if (bestMoves.Count == 0)
            {
                Die();
                return;
            }

            _designedMove = bestMoves[Random.Range(0, bestMoves.Count)];
        }

        public override void Execute()
        {
            if (_die) return;

            _lastCell = _cells[_cells.Count - 1];
            _startCell = _designedMove(_startCell);

            var cellsText = string.Empty;
            foreach (var cell in _cells)
            {
                cellsText += " " + cell;
            }
            Debug.Log($"Start: {_startCell} Last: {_lastCell} {cellsText}");
            
            _cells.RemoveAt(_cells.Count - 1);
            _cells.Insert(0, _startCell);
            
            _gameManager.AssignGameEntityToGameFieldCell(this, _startCell);
            _gameManager.UnassignGameEntityToGameFieldCell(this, _lastCell);
        }

        public override void ApplyGameStateChanges()
        {
            base.ApplyGameStateChanges();
            
            if (_die) return;
            
            StartCoroutine(MovingCoroutine());
        }

        private IEnumerator MovingCoroutine()
        {
            var time = 0f;
            var n = _snakeParts.Count;
            var startPos = new Vector3[n];
            var endPos = new Vector3[n];

            for (var i = 0; i < n; i++)
            {
                startPos[i] = _snakeParts[i].position;
                endPos[i] = _gameManager.GameCellToWorldCoords(_cells[i]);
            }

            if (_growth)
            {
                _cells.Add(_lastCell);
                _gameManager.AssignGameEntityToGameFieldCell(this, _lastCell);
                var snakePart = Instantiate(_gameManager.Settings.SnakePartPrefab,
                    _gameManager.GameCellToWorldCoords(_lastCell),
                    Quaternion.identity,
                    transform);
                _snakeParts.Add(snakePart.transform);
            }
            
            while (time < _gameManager.Settings.TickTime)
            {
                var stage = time / _gameManager.Settings.TickTime;
                
                for (var i = 0; i < n; i++)
                {
                    _snakeParts[i].position = Vector3.Lerp(startPos[i], endPos[i], stage);
                }

                time += Time.deltaTime;
                yield return null;
            }
        }

        public void Growth()
        {
            _growth = true;
        }
    }
}